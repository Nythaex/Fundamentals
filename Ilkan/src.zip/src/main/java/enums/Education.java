package enums;

public enum Education {
    BACHELOR,MASTER,DOCTOR,DOCTOR_ОF_SCIENCE
}
