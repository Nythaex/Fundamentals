package enums;

public enum Gender {
    Man,Woman
}
